//@prepros-prepend googlemaps.js

/* IF MOBILE */
var isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent) ;

/* DOCUMENT READY */
$(document).ready(function(){

  /* Menu Hover */
  $('.dropdown-toggle').mouseover( function(e){
    e.preventDefault();
    $(this).next('.dropdown-menu').addClass('show');
  });

  $('.dropdown-menu').mouseleave( function(e){
    e.preventDefault();
    $(this).removeClass('show');
  });

  /* ACF MAPS */
  $('.acf-map').each(function(){

		// create map
		map = new_map( $(this) );

	});

  /* Remove Loading Screen */
  setTimeout(function(){
    $('.loading-container').css('opacity', '0').delay(1000).queue(function(next){
      $(this).css('z-index', '-10');
      next();
    });
    $('body').css('overflow', 'auto');
    AOS.init({
      duration: 800,
      disable: 'mobile'
    });
  }, 2000);

  /* Navbar Collapse Animation */
  $('.navbar-toggler').on("click", function(){
    var expanded = $(this).attr('aria-expanded');

    if (expanded == "true") {
      setTimeout(function(){
        $('#navbarNavDropdown').removeClass('collapse');
      }, 800)
    }

  });

});

if (!isMobile) {

  /* FUNCTIONS */
  function parallaxScroll(){
    var scrolledY = $(window).scrollTop();
    $('.innerbanner-section').css('background-position','center '+((scrolledY*0.2))+'px');
    $('.vertical-bar').css('bottom',' -'+((scrolledY*0.08))+'px').css('bottom','-=7%');
    $('.support-vertical-bar').css('bottom',' -'+((scrolledY*0.10))+'px').css('bottom','-=50%');
  }

  $(window).bind('scroll',function(e){

    /* Run Parallax Function */
    parallaxScroll();

  });

}

$(window).bind('scroll',function(e){

  /* Change Navbar Background Color */
  var scroll = $(window).scrollTop();
  if (scroll > 50) {
    $('.navbar').addClass('navbar-psbackground');
  }else{
    $('.navbar').removeClass('navbar-psbackground ');
  }

});
