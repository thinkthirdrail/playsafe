_playsafe

Playsafe - Custom Wordpress Template

Run 'npm install' to install the dependencies:

  - Grunt, Grunt Copy
  - Bootstrap
  - Font Awesome
  - jQuery
  - Slick Slider

After the installation, run 'grunt' to copy all the files from node_modules to the 'src' and 'assets' folders.

Use 'src/scss/theme' for all the custom SCSS and 'src/js/theme' for all the custom JS.
If you want to add any new SCSS or JS files, you need to add them on 'style.scss' and 'scripts.js' inside 'src/scss' and 'src/js'.

That's it, now go to work!
